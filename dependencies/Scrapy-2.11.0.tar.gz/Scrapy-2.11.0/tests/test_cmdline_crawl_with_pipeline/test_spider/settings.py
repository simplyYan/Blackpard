BOT_NAME = "test_spider"
SPIDER_MODULES = ["test_spider.spiders"]
