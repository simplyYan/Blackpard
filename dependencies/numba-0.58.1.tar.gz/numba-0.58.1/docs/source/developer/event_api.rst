Event API
=========

.. automodule:: numba.core.event
    :members: