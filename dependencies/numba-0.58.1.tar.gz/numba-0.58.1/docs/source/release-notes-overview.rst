======================
Release Notes
======================

Towncrier generated notes:
--------------------------

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   release/*

Non-Towncrier generated notes:
------------------------------

.. toctree::
   :maxdepth: 1

   release-notes.rst
