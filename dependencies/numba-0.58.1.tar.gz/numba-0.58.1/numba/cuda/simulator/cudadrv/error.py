class CudaSupportError(RuntimeError):
    pass


class NvrtcError(Exception):
    pass
