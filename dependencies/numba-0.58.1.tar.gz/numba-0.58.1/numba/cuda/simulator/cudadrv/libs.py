def check_static_lib(lib):
    raise FileNotFoundError('Linking libraries not supported by cudasim')
